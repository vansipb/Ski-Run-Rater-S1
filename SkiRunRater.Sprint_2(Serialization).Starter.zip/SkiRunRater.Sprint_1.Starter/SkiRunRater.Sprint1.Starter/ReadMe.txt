﻿Title: Ski Run Rater
Description: In this code we had to add some items and edit them to make them function properally
Application Type: Console
Author: Ben VanSipe
Dated Created: 11/4/2017
Last Modified: 11/3/2017