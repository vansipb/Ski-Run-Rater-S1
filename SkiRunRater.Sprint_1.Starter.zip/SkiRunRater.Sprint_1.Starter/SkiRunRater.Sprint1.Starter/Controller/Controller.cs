﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkiRunRater
{
    public class Controller
    {
        #region ENUMERABLES


        #endregion

        #region FIELDS

        bool active = true;

        #endregion

        #region PROPERTIES


        #endregion

        #region CONSTRUCTORS

        public Controller()
        {
            ApplicationControl();
        }

        #endregion

        #region METHODS

        private void ApplicationControl()
        {
            SkiRunRepository skiRunRepository = new SkiRunRepository();

            ConsoleView.DisplayWelcomeScreen();

            using (skiRunRepository)
            {
                List<SkiRun> skiRuns = skiRunRepository.GetSkiAllRuns();

                int skiRunID;
                SkiRun skiRun;
                string message;

                while (active)
                {
                    AppEnum.ManagerAction userActionChoice;

                    userActionChoice = ConsoleView.GetUserActionChoice();

                    switch (userActionChoice)
                    {
                        case AppEnum.ManagerAction.None:
                            break;
                        case AppEnum.ManagerAction.ListAllSkiRuns:
                            ConsoleView.DisplayAllSkiRuns(skiRuns);
                            ConsoleView.DisplayContinuePrompt();
                            break;
                        case AppEnum.ManagerAction.DisplaySkiRunDetail:
                            skiRunID = ConsoleView.GetSkiRunID(skiRuns);
                            skiRun = skiRunRepository.GetSkiRunByID(skiRunID);
                            ConsoleView.DisplaySkiRun(skiRun);
                            ConsoleView.DisplayContinuePrompt();
                            break;
                        case AppEnum.ManagerAction.DeleteSkiRun:
                            skiRunRepository.DeleteSkiRun(ConsoleView.DeleteChoice());
                            ConsoleView.DisplayReset();
                            ConsoleView.DisplayMessage("The Ski Run has been deleted.");
                            ConsoleView.DisplayContinuePrompt();
                            break;
                        case AppEnum.ManagerAction.AddSkiRun:
                            skiRunRepository.InsertSkiRun(ConsoleView.AddSkiRun());
                            ConsoleView.DisplayContinuePrompt();
                            break;
                        case AppEnum.ManagerAction.UpdateSkiRun:
                            skiRunID = ConsoleView.GetSkiRunID(skiRuns);
                            skiRun = skiRunRepository.GetSkiRunByID(skiRunID);
                            skiRun = ConsoleView.UpdateSkiRun(skiRun);
                            skiRunRepository.UpdateSkiRun(skiRun);
                            break;
                        case AppEnum.ManagerAction.QuerySkiRunsByVertical:
                            List<SkiRun> skiRunList = new List<SkiRun>();
                            int minimumVertical;
                            int maximumVertical;
                            ConsoleView.GetVerticalQueryMinMaxValues(out minimumVertical, out maximumVertical);
                            ConsoleView.DisplayQueryResults(skiRunRepository.QueryByVertical(minimumVertical, maximumVertical));
                            ConsoleView.DisplayContinuePrompt();
                            break;
                        case AppEnum.ManagerAction.Quit:
                            active = false;
                            break;
                        default:
                            break;
                    }
                }
            }

            ConsoleView.DisplayExitPrompt();
        }

        #endregion

    }
}
